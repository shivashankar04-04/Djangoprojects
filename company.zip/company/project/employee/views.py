from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse

def employee(request):
    return render(request,'employee/employee.html')

def profile(request):
    return render(request,'employee/profile.html')


